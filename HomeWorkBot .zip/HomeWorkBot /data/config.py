# coding: utf-8

settings = {
    "token": "тут токен сообщества"
}
