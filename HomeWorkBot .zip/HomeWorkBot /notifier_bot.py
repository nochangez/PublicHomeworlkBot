# coding: utf-8

from random import randint
from datetime import datetime

import vk_api
from vk_api.utils import get_random_id
from vk_api.keyboard import VkKeyboard, VkKeyboardColor
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType

from data.config import settings
from services.help_stuff import HelpStuff
from services.commands import Commands, ReadyCommands
from services.callback_queries import CallbackQueries

try:
    # authorize as community
    vk_session = vk_api.VkApi(token=settings['token'])
    bot_longpoll = VkBotLongPoll(vk_session, 207024246)
    vk = vk_session.get_api()

    # long poll server info
    connection_data = vk.groups.getLongPollServer(group_id=207024246)
    long_poll_server_key = connection_data['key']  # key
    long_poll_server_url = connection_data['server']  # server
    long_poll_server_timestamp = connection_data['ts']  # ts

    bot_logging_in_time = datetime.now().strftime("%H:%M:%S")
    print(f"[bot:homeworkbot] logged in at ~ {bot_logging_in_time} ~")
except Exception as logging_bot_block_error:
    logging_bot_block_error_time = datetime.now().strftime("%H:%M:%S")
    print(f"[error:{logging_bot_block_error_time}] {logging_bot_block_error}")

# inline homework keyboar
try:
    # inline keyboard settings
    inline_keyboard_settings = dict(one_time=False, inline=True)

    # add inline keyboard
    homework_keyboard = VkKeyboard(**inline_keyboard_settings)
    homework_keyboard.add_callback_button("расписание", color=VkKeyboardColor.POSITIVE, payload={
        "type": "callback", "label": "timetable"
    })
    # homework_keyboard.add_line()
    homework_keyboard.add_callback_button("дз", color=VkKeyboardColor.NEGATIVE, payload={
        "type": "callback", 'label': "current_homework"
    })
except Exception as keyboard_code_block_error:
    keyboard_code_block_error_time = datetime.now().strftime("%H:%M:%S")
    print(f"[error:{keyboard_code_block_error_time}] {keyboard_code_block_error}")

# main full time keyboard
try:
    # main keyboard settings
    main_keyboard_settings = dict(one_time=False, inline=False)

    # add main keyboard
    global main_keyboard
    main_keyboard = VkKeyboard(**main_keyboard_settings)
    main_keyboard.add_callback_button("команды", color=VkKeyboardColor.POSITIVE, payload={
        "type": "callback", "label": "commands"
    })
    main_keyboard.add_callback_button("помощь", color=VkKeyboardColor.NEGATIVE, payload={
        "type": "callback", "label": "get_help"
    })
except Exception as main_keyboard_code_block_error:
    main_keyboard_code_block_error_time = datetime.now().strftime("%H:%M:%S")
    print(f"[error:{main_keyboard_code_block_error_time}] {main_keyboard_code_block_error}")


def main():
    try:
        for event in bot_longpoll.listen():
            if event.type == VkBotEventType.MESSAGE_NEW and event.from_chat:
                # base variables for new_message from_chat event
                message: str = event.message.text  # user message text
                chat_id: int = event.chat_id  # the id of a chat where message was registered
                peer_id: int = event.object.message.get("peer_id")  # the common object (message, user, chat) id
                sender_id: int = event.from_user  # the user id who sent a message
                first_message_char: str = message[0]  # check if message is a command
                commands = Commands(sender_id=sender_id)  # init commands class
                ready_commands = ReadyCommands(sender_id=sender_id)  # init ready_commands class
                help_stuff = HelpStuff()  # class with help features and data

                # load main keyboard
                was_keyboard_sent = help_stuff.check_main_keyboard_status()
                if not was_sent:
                    vk.messages.send(
                        key=long_poll_server_key, server=long_poll_server_url, ts=long_poll_server_timestamp,
                        peer_id=peer_id, random_id=get_random_id(), message="вот клавиатура",
                        keyboard=main_keyboard.get_keyboard()
                    )
                    was_sent = True

                def short_send(message_short_send, keyboard_obj=None):
                    """Shorted function for messaging
                    vk.messages.send(..., message='some text') -> short_send(message='some text')
                    """
                    # try:
                    if keyboard_obj is None:
                        vk.messages.send(
                            key=long_poll_server_key, server=long_poll_server_url, ts=long_poll_server_timestamp,
                            chat_id=chat_id, random_id=get_random_id(), message=message_short_send
                        )
                    else:
                        vk.messages.send(
                            key=long_poll_server_key, server=long_poll_server_url, ts=long_poll_server_timestamp,
                            chat_id=chat_id, random_id=get_random_id(), keyboard=keyboard_obj.get_keyboard(),
                            message=message_short_send
                        )
                    # except Exception as short_send_code_block_error:
                    #     short_send_code_block_error_time = datetime.now().strftime("%H:%M:%S")
                    #     print(f"[error:{short_send_code_block_error_time}] {short_send_code_block_error}")

                # init if the user message is the command
                if first_message_char == '/':
                    # base variables for command block
                    command: str = message.split('/')[1]  # command body - no prefix
                    avaliable_commands: dict = commands.all_commands  # get all available commands

                    # check if command exists
                    if command in avaliable_commands:
                        # command replies
                        if command in ("админы", "команды"):
                            user_command_answers = {
                                "админы": ready_commands.prettify_get_bot_admins(),
                                "команды": ready_commands.prettify_get_bot_commands(),
                            }
                            short_send(message_short_send=user_command_answers[command])
                        else:
                            if command == "клавиатура":
                                # load the keyboard
                                choose_variant_texts = ("выбирай", "вот", "жду жду")
                                random_index_for_choose_text = randint(0, (len(choose_variant_texts) - 1))
                                short_send(message_short_send=choose_variant_texts[random_index_for_choose_text],
                                           keyboard_obj=homework_keyboard
                                           )
                    else:
                        short_send(message_short_send="ало лошпедус нет такой команды")
            elif event.type == VkBotEventType.MESSAGE_EVENT:
                user_keyboard_choice_type = event.object.payload.get('type')
                if user_keyboard_choice_type == "callback":
                    # base variables for callback queries handler block
                    peer_id: int = event.object.peer_id  # the common object (message, user, chat) id
                    print(peer_id)
                    callback_queries = CallbackQueries()  # init callback_queries class
                    callback_label: str = event.object.payload.get('label')  # callback special name
                    user_keyboard_choice: str = event.object.payload.get('label')  # user button choice (callback value)
                    conversation_message_id: int = event.object.conversation_message_id  # message id in a chat

                    # edit message to the set choice message
                    texts_for_callback_replies = {
                        "timetable": "загружаю расписание...",
                        "current_homework": "сейчас посмотрим чево задали...",
                    }
                    user_callback_reply_text = texts_for_callback_replies[user_keyboard_choice]
                    vk.messages.edit(
                        peer_id=peer_id, random_id=get_random_id(), conversation_message_id=conversation_message_id,
                        message=user_callback_reply_text
                    )

                    # call method for the user callback
                    callback_queries_methods = {
                        "timetable": callback_queries.load_timetable(),
                        "current_homework": callback_queries.load_homework()
                    }
                    # call the method for its callback query
                    answer_click_button_text = callback_queries_methods[callback_label]
                    vk.messages.send(
                        key=long_poll_server_key, server=long_poll_server_url, ts=long_poll_server_timestamp,
                        peer_id=peer_id, random_id=get_random_id(), message=answer_click_button_text
                    )
    except KeyboardInterrupt:
        print("\n[exit] end session")
    # except Exception as main_code_block_error:
    #     main_code_block_error_time = datetime.now().strftime("%H:%M:%S")
    #     print(f"[error:{main_code_block_error_time}] {main_code_block_error}")


if __name__ == "__main__":
    main()
