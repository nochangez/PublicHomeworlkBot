# coding: utf-8

import sqlite3

# global variables
global connection, cursor


try:
    # bd creating/opening
    connection = sqlite3.connect("data/database.db")
    cursor = connection.cursor()

    # create admin table
    cursor.execute("CREATE TABLE service_storage (was_sent number)")
    connection.commit()
    # start value is false : bool(0)
    cursor.execute("INSERT INTO TABLE service_storage VALUES ('0')")
    connection.commit()
except:
    pass


class HelpStuff:
    """Class with help functions"""
    @staticmethod
    def check_main_keyboard_status() -> bool:
        """Functions gets status of main keyboard (was showed or not)

        Returns:
            bool: was keyboard showed?
        """
        # get current status
        cursor.execute("SELECT * FROM service_storage ORDER BY was_sent")
        __result__: list = cursor.fetchall()  # unfiltered bool value in service
        __filtered_result__: int = __result__[0][0]
        was_keyboard_sent: bool = bool(__filtered_result__)

        return was_keyboard_sent


test = HelpStuff()
print(test.check_main_keyboard_status())
