# coding=utf-8

import sqlite3


try:
    # bd creating/opening
    connection = sqlite3.connect("data/database.db")
    cursor = connection.cursor()

    # create admin table
    cursor.execute("CREATE TABLE admins (admin_id number)")
    connection.commit()
except:
    pass  # ignore if table already exists


class Commands:
    """Class for processing bot commands

    Contains functions that named as their commands
    """
    def __init__(self, sender_id):
        self.all_commands = {
            "админы": "получить список администраторов",
            "команды": "получить список всех доступных команд с их описанием",
            "клавиатура": "появляется клавиатура с дз и расписанием",
        }
        self.__sender_id = sender_id

    @staticmethod
    def get_bot_admins() -> list:
        """Getting bot admins via request to database

        Returns:
            list: sequence of user ids that have role 'admin'
        """
        cursor.execute("SELECT * FROM admins")
        admins = cursor.fetchall()  # all admins looks now: [(admin_id,)]

        counter = 0
        admins_prettified = []  # prettified admin ids
        for i in range(len(admins[0])):
            admins_prettified.append(admins[0][counter])
            counter += 1

        return admins_prettified


class ReadyCommands(Commands):
    """Class ReadyCommands exists for prettifing returns to users"""
    def prettify_get_bot_admins(self) -> str:
        """Making gotten admins ids the message string

        Returns:
            str: ready message to send
        """
        admins = self.get_bot_admins()
        admins_count = len(admins)
        admins_ids_message = f"всего админов: {admins_count}"
        for admin_id in admins:
            admins_ids_message += f"\n - @id{admin_id}"

        return admins_ids_message

    def prettify_get_bot_commands(self) -> str:
        """Collect all bot commands in one string for message

        Returns:
            str: a string with commands and their destinitions
        """
        all_commands_message = "все доступные команды:\n\n"
        for command_name in self.all_commands:
            all_commands_message += f"/{command_name} -- {self.all_commands[command_name]}\n"

        return all_commands_message
