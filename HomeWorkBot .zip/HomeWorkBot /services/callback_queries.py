# coding=utf-8



class CallbackQueries:
    """Class is used for getting some data as response to callback query"""
    @staticmethod
    def load_timetable() -> str:
        """Loads the timetable of classes for current day

        Returns:
            str: message with the timetable
        """
        return "test timetable message"

    @staticmethod
    def load_homework() -> str:
        """Loads the homework for current day

        Returns:
            str: message with the homework data
        """
        return "test homework message"